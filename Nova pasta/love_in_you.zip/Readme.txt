- This is for PERSONAL USE ONLY. NO COMMERCIAL USE ALLOWED!

- For ADDITIONAL FULL FITURES purchase full version and commercial license,
  please contact us at:
  email: cs.prastart@gmail.com
  whatsapp: +62 (Indonesia) 82140965486 

- Any donation are very appreciated. Paypal account for donation: 
  https://paypal.me/prastart

INDONESIA:

Dengan meng-install, berarti Anda mengerti dan menyetujui ketentuan berikut:

- Font demo ini hanya untuk "Personal Use" saja, dengan pengertian lain Anda DILARANG KERAS menggunakan font ini untuk tujuan komersil yang menghasilkan profit, baik berupa individu, korporasi, jasa percetakan, agensi desain grafis dll seperti: untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

- Gunakan lisensi komersial dengan membeli melalui kontak resmi kami.

Terima kasih.